//
//  DisplaySearchResultTableViewCell.swift
//  TestAssignment_Sharad
//
//  Created by Sharad Patil on 14/04/22.
//  Copyright © 2022 Sharad. All rights reserved.
//

import UIKit

class DisplaySearchResultTableViewCell: UITableViewCell {
    @IBOutlet weak var avatarUrlLabel: UILabel!
    @IBOutlet weak var loginLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
