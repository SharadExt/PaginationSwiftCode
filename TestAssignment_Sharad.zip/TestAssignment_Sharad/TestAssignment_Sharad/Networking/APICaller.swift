//
//  APICaller.swift
//  TestAssignment_Sharad
//
//  Created by Sharad Patil on 14/04/22.
//  Copyright © 2022 Sharad. All rights reserved.
//

import Foundation
import Moya
import Alamofire

class APICaller {
    
    var isPaginating = false
    
    func loadMoreItems(_ pageNo:Int, withInputText inputStr:String,pagination:Bool, completion:@escaping (Result<URLDetails,Error>) -> Void) {
        
        if pagination {
            isPaginating = true
        }
        
        let pno = String(pageNo)
        let request = AF.request("https://api.github.com/search/users?q=\(inputStr)%20in:login&per_page=9&page=\(pno)")
        
        request.responseDecodable(of: URLDetails.self) { (response) in
            if response.value != nil {
                completion(.success(response.value!))
                if pagination {
                    //Should not have multiple request
                    self.isPaginating = false
                }
            } else {
                completion(.failure(response.error!))
            }   
        }
    }
}
