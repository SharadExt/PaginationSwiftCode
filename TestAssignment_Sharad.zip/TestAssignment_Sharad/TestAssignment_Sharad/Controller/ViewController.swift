//
//  ViewController.swift
//  TestAssignment_Sharad
//
//  Created by Sharad Patil on 14/04/22.
//  Copyright © 2022 Sharad. All rights reserved.
//

import UIKit
import Moya
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var loginTextView: UITextView!
    @IBOutlet weak var displaySearchTableView: UITableView!
    @IBOutlet weak var mainViewHeightLayoutConstraint: NSLayoutConstraint!
    
    var dataItemsArray: [DataURLDetails] = []
    var pageNumber : Int = 1
    
    private let apiCaller = APICaller()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func submitButtonTapped(_ sender: Any) {
        dataItemsArray = []
        pageNumber = 1
        apiCaller.isPaginating = false
        
        apiCaller.loadMoreItems(pageNumber, withInputText: loginTextView.text, pagination: false) {[weak self] result in
        
            switch result {
            
            case .success(let receivedData):
                self?.dataItemsArray.append(contentsOf: receivedData.items)
                DispatchQueue.main.async {
                    self?.displaySearchTableView.reloadData()
                }
                
            case .failure(let failError):
                self?.displayErrorAlert(failError.localizedDescription)
                break
            }
        }
    }
    
    func displayErrorAlert(_ responseError:String) {
        let alertController = UIAlertController(title: "Error", message: responseError, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
            
            //Handle action on button Ok
            
        }))
        self.present(alertController, animated: true)
    }
    
    func startSpinner() -> UIView {
        let footerView =  UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 300))
        let spinner = UIActivityIndicatorView()
        spinner.center = footerView.center
        footerView.addSubview(spinner)
        spinner.startAnimating()
        
        return footerView
    }
}

extension ViewController:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        dataItemsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DisplayCell",for: indexPath as IndexPath) as! DisplaySearchResultTableViewCell
        
        if(dataItemsArray.count > 0) {
            cell.avatarUrlLabel.text = dataItemsArray[indexPath.row].avatar_url
            cell.loginLabel.text = dataItemsArray[indexPath.row].login
            cell.typeLabel.text = dataItemsArray[indexPath.row].type
            
        } else {
            print("Empty Array")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return mainViewHeightLayoutConstraint.constant/9
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let position = scrollView.contentOffset.y
        if position > (displaySearchTableView.contentSize.height-100-scrollView.frame.size.height){
            guard !apiCaller.isPaginating else {
                print("Already fetching more data")
                return
            }
            
            self.displaySearchTableView.tableFooterView = startSpinner()
            
            pageNumber += 1
            
            apiCaller.loadMoreItems(pageNumber, withInputText: loginTextView.text, pagination: true) { [weak self] result in
                
                DispatchQueue.main.async {
                    self?.displaySearchTableView.tableFooterView = nil
                }
                
                switch result {
                    
                case .success(let receivedData):
                    self?.dataItemsArray.append(contentsOf: receivedData.items)
                    print("Update items Count ",self!.dataItemsArray.count)
                    DispatchQueue.main.async {
                        self?.displaySearchTableView.reloadData()
                    }
                    
                case .failure(let failError):
                    self?.displayErrorAlert(failError.localizedDescription)
                    break
                }
            }
        }
    }
}




